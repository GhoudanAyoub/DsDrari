package models;

public interface ClientDAO {
	public Client getClient(String email,String password);
	public int addClient(Client client);
	
}
