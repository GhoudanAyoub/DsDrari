package models;

import java.util.List;

public interface ArticleDAO {
	public List<Article> getAllArticle();
	public Article getArticle(int id);
}
