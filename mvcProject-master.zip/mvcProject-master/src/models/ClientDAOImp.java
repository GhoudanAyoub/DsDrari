package models;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;



public class ClientDAOImp implements ClientDAO {

	@Override
	public Client getClient(String email, String password) {
		// TODO Auto-generated method stub
		PreparedStatement pst;
		ResultSet rs;
		Client c = null;
		String req = "SELECT * FROM clients where email=? and password = ? limit 0,1";
		try {
			Connection co = DatabaseConnection.getInstance().getConnection();
			pst = co.prepareStatement(req);
			pst.setString(1, email);
			pst.setString(2, password);
			rs =pst.executeQuery();
			while(rs.next()) {
				 c = new Client(rs.getInt(1), rs.getString(4), rs.getString(5),rs.getString(2),rs.getString(3));
			}
		}catch(SQLException e) {
			e.printStackTrace();
			return null;
		}
		return c;
	}

	@Override
	public int addClient(Client client) {
		
		PreparedStatement pst;
		PreparedStatement pst1;

		ResultSet rs1;

		String checking = "SELECT * FROM clients where email=?  limit 0,1";
		// TODO Auto-generated method stub
		String req = "INSERT INTO clients(nom,prenom,email,password) VALUES(?,?,?,?)";
		try {
			Connection co = DatabaseConnection.getInstance().getConnection();
			pst1 = co.prepareStatement(checking);
			pst1.setString(1, client.getEmail());
			rs1 =pst1.executeQuery();
			if(rs1.next() != false) {
				return -1;
			}else {
				pst = co.prepareStatement(req);
				pst.setString(1, client.getNom());
				pst.setString(2, client.getPrenom());
				pst.setString(3, client.getEmail());
				pst.setString(4, client.getPassword());
				pst.executeUpdate();
			}
		
			
		}catch(SQLException e) {
			e.printStackTrace();
			return 0;
		}
		return 1;

	}
	

}
