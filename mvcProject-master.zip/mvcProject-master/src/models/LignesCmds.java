package models;

public class LignesCmds {
	private int commande_id;
	private int article_id;
	public int getCommande_id() {
		return commande_id;
	}
	public void setCommande_id(int commande_id) {
		this.commande_id = commande_id;
	}
	public int getArticle_id() {
		return article_id;
	}
	public void setArticle_id(int article_id) {
		this.article_id = article_id;
	}
	public LignesCmds(int commande_id, int article_id) {
		super();
		this.commande_id = commande_id;
		this.article_id = article_id;
	}
}
