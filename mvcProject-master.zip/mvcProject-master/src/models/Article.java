package models;

public class Article {
	private int id;
	private int prix;
	private int stock;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getPrix() {
		return prix;
	}
	public void setPrix(int prix) {
		this.prix = prix;
	}
	public int getStock() {
		return stock;
	}
	public void setStock(int stock) {
		this.stock = stock;
	}
	public String getTitre() {
		return titre;
	}
	public void setTitre(String titre) {
		this.titre = titre;
	}
	public String getAuteur() {
		return auteur;
	}
	public void setAuteur(String auteur) {
		this.auteur = auteur;
	}
	public String getEditeur() {
		return editeur;
	}
	public void setEditeur(String editeur) {
		this.editeur = editeur;
	}
	public String getCategorie() {
		return categorie;
	}
	public void setCategorie(String categorie) {
		this.categorie = categorie;
	}
	public String getPhoto() {
		return photo;
	}
	public void setPhoto(String photo) {
		this.photo = photo;
	}
	public Article() {}
	public Article(int id, int prix, int stock, String categorie, String photo,String editeur,String auteur, String titre 
			) {
		super();
		this.id = id;
		this.prix = prix;
		this.stock = stock;
		this.titre = titre;
		this.auteur = auteur;
		this.editeur = editeur;
		this.categorie = categorie;
		this.photo = photo;
	}
	private String titre;
	private String auteur;
	private String editeur;
	private String categorie;
	private String photo;
	
}
