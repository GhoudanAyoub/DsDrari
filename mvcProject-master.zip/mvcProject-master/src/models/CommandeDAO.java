package models;

import java.util.List;

public interface CommandeDAO {
	public List<Commande> getAllCommandes(int client_id);
	public void addCommande(Panier p,int commande_id);
 public int addSp(int id);
}
