package models;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ArticleDAOImp implements ArticleDAO {

	@Override
	public List<Article> getAllArticle() {
		PreparedStatement pst;
		ResultSet rs;
		List<Article> lc = new ArrayList<>();
		String req = "SELECT * FROM articles";
		try {
			Connection co = DatabaseConnection.getInstance().getConnection();
			pst = co.prepareStatement(req);
			rs =pst.executeQuery();
			while(rs.next()) {
				 Article a = new Article(rs.getInt(1), rs.getInt(2), rs.getInt(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8));
				lc.add(a);
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return lc;
	}

	@Override
	public Article getArticle(int id) {
		PreparedStatement pst;
		ResultSet rs;
		Article a = null;
		String req = "SELECT * FROM articles where id=? limit 0,1";
		try {
			Connection co = DatabaseConnection.getInstance().getConnection();
			pst = co.prepareStatement(req);
			pst.setInt(1, id);
			rs =pst.executeQuery();
			while(rs.next()) {
				 a = new Article(rs.getInt(1), rs.getInt(2), rs.getInt(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8));
			}
		}catch(SQLException e) {
			e.printStackTrace();
			return null;
		}
		return a;
	}

}
