package models;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CommandeDAOImp implements CommandeDAO {

	@Override
	public List<Commande> getAllCommandes(int id) {
		// TODO Auto-generated method stub
		PreparedStatement pst;
		ResultSet rs;
		List<Commande> lc = new ArrayList<>();
		String req = "SELECT * FROM commandes where client_id = ?";
		try {
			Connection co = DatabaseConnection.getInstance().getConnection();
			pst = co.prepareStatement(req);
			pst.setInt(1, id);
			rs =pst.executeQuery();
			while(rs.next()) {
				 Commande c = new Commande(rs.getInt(1), rs.getInt(2), rs.getDate(3));
				lc.add(c);
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return lc;
	}


	@Override
	public int addSp(int id) {
		// TODO Auto-generated method stub
		PreparedStatement pst;
		int last = 0;
		String req = "INSERT INTO commandes(client_id) VALUES(?)";
		try {
			Connection co = DatabaseConnection.getInstance().getConnection();
			pst = co.prepareStatement(req);
			pst.setInt(1, id);
			pst.executeUpdate();
			ResultSet rs=pst.getGeneratedKeys();
			if(rs.next()){
				last=rs.getInt(1);
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return last;
	}

	@Override
	public void addCommande(Panier p, int commande_id) {
		// TODO Auto-generated method stub
		PreparedStatement pst;
		String req = "INSERT INTO lignes_cmds(commande_id,article_id,qtecde) VALUES(?,?,1)";
		try {
			Connection co = DatabaseConnection.getInstance().getConnection();
			pst = co.prepareStatement(req);
			pst.setInt(1, commande_id);
			pst.setInt(2, p.getArticle_id());
			pst.executeUpdate();
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
}
