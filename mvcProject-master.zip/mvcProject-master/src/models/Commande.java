package models;

import java.util.Date;

public class Commande {
	private int id;
	private int client_id;
	private Date date_commande;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getClient_id() {
		return client_id;
	}
	public void setClient_id(int client_id) {
		this.client_id = client_id;
	}
	public Date getDate_commande() {
		return date_commande;
	}
	public void setDate_commande(Date date_commande) {
		this.date_commande = date_commande;
	}
	public Commande(int id, int client_id, Date date_commande) {
		super();
		this.id = id;
		this.client_id = client_id;
		this.date_commande = date_commande;
	}
	public Commande(int client_id, Date date_commande) {
		super();
		this.client_id = client_id;
		this.date_commande = date_commande;
	}
}
