package models;

public class Panier {
	private int client_id;
	private int article_id;
	private int qte;
	private int prix;
	private String titre;

	public Panier(int client_id, int article_id, int qte, int prix, String titre) {
		super();
		this.client_id = client_id;
		this.article_id = article_id;
		this.qte = qte;
		this.prix = prix;
		this.titre = titre;
	}

	public String getTitre() {
		return titre;
	}

	public void setTitre(String titre) {
		this.titre = titre;
	}

	public int getClient_id() {
		return client_id;
	}
	public void setClient_id(int client_id) {
		this.client_id = client_id;
	}
	public int getArticle_id() {
		return article_id;
	}
	public void setArticle_id(int article_id) {
		this.article_id = article_id;
	}
	public int getQte() {
		return qte;
	}
	public void setQte(int qte) {
		this.qte = qte;
	}
	public int getPrix() {
		return prix;
	}
	public void setPrix(int prix) {
		this.prix = prix;
	}
}
