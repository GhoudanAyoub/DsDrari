package controllers;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import models.Client;
import models.ClientDAOImp;

/**
 * Servlet implementation class inscriptionController
 */
@WebServlet("/inscriptionController")
public class inscriptionController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public inscriptionController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
				String address="";
				String email =  request.getParameter("email");
				String password =  request.getParameter("pwd");
				String nom =  request.getParameter("nom");
				String prenom =  request.getParameter("prenom");
			    HttpSession sess = request.getSession();

				ClientDAOImp impl = new ClientDAOImp();
				Client c1 =  new Client(nom,prenom,email,password);
				int res = impl.addClient(c1);
				if(res == 1) {
				    sess.setAttribute("nom", c1.getNom());
				    sess.setAttribute("prenom", c1.getPrenom());
				    sess.setAttribute("client_id", c1.getId());
				    address="welcome.jsp";
				}else if(res == 0){
					request.setAttribute("error", "Veuillez v�rifier vos donn�es");
					address="inscription.jsp";
				}else if(res == -1) {
					request.setAttribute("error", "Email existe d�ja");
					address="inscription.jsp";
				}
				RequestDispatcher dispatcher =  request.getRequestDispatcher(address);
				dispatcher.forward(request, response);		}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
