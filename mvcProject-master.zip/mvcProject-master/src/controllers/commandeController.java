package controllers;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import models.Commande;
import models.CommandeDAO;
import models.CommandeDAOImp;
import models.Panier;

/**
 * Servlet implementation class commandeController
 */
@WebServlet("/commandeController")
public class commandeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public commandeController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	    HttpSession sess = request.getSession();
	    int client_id = (int) sess.getAttribute("client_id");
	    
	    List<Panier> lp = (List<Panier>) sess.getAttribute("panier");
	    CommandeDAO cmdImp = new CommandeDAOImp();
	    int commande_id = cmdImp.addSp(client_id);
	    for(Panier p : lp) {
	    	cmdImp.addCommande(p,commande_id);
	    }
		RequestDispatcher dispatcher =  request.getRequestDispatcher("final.jsp");
		dispatcher.forward(request, response);	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
