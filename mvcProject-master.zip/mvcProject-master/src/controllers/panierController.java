package controllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import models.Panier;

/**
 * Servlet implementation class panierController
 */
@WebServlet("/panierController")
public class panierController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public panierController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	    HttpSession sess = request.getSession();
		int client_id = Integer.parseInt(request.getParameter("client_id"));
		int article_id = Integer.parseInt(request.getParameter("article_id"));
		int qte =  Integer.parseInt(request.getParameter("qte"));
		int prix = Integer.parseInt(request.getParameter("prix"));
		String titre = request.getParameter("titre");
		Panier pan = new Panier(client_id,article_id,qte,prix,titre);
		List<Panier>  lpan = new ArrayList<Panier>();		
		 if (sess.isNew()) {			 
			 lpan.add(pan);
			} else {
				
				if(sess.getAttribute("panier") != null) {
 				lpan =  (List<Panier>) sess.getAttribute("panier");
 				lpan.add(pan); 				
				}else {
					lpan.add(pan);
				}
			}	
  		sess.setAttribute("panier", lpan);
		RequestDispatcher dispatcher =  request.getRequestDispatcher("Panier.jsp");
		dispatcher.forward(request, response);	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
